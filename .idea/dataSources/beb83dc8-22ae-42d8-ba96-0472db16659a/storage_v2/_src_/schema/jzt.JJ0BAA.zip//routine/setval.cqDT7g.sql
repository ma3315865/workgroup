create function setval(seq_name varchar(64), value int)
  returns bigint
  BEGIN
         UPDATE sequence
                   SET current_value = value
                   WHERE name = seq_name;
         RETURN currval(seq_name);
END;

