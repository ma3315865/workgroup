create function nextval(seq_name varchar(64))
  returns bigint
  BEGIN
         UPDATE sequence
                   SET current_value = current_value + increment
                   WHERE name = seq_name;
         RETURN currval(seq_name);
END;

