create procedure pro_get_number(IN  v_yyyymmdd varchar(32), IN v_type varchar(32), IN v_length int,
                                OUT result     varchar(128))
  BEGIN
	DECLARE ncount INTEGER;
	DECLARE v_latest_no INTEGER;
	DECLARE  v_str VARCHAR(512);
	SELECT COUNT(1) INTO ncount FROM order_order_sequence WHERE yyyymmdd = v_yyyymmdd AND type = v_type;
	IF ncount = 0
	THEN
		INSERT INTO order_order_sequence(yyyymmdd,type,current_value) VALUES(v_yyyymmdd,v_type,1); 
		SET v_latest_no = 1;
	ELSE
		UPDATE order_order_sequence SET current_value = current_value+1 WHERE yyyymmdd = v_yyyymmdd AND type = v_type;
		SELECT current_value INTO v_latest_no FROM order_order_sequence WHERE yyyymmdd = v_yyyymmdd AND type = v_type;
	END IF;
    
	SET v_str = LPAD(v_latest_no, v_length - LENGTH(v_yyyymmdd), '0');
    SET v_str = CONCAT(v_yyyymmdd, v_str);
	SELECT CONCAT(v_type, v_str) INTO result;
END;

