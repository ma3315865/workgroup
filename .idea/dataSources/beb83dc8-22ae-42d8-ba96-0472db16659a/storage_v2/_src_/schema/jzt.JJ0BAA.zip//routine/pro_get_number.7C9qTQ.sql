create procedure pro_get_number(IN  v_Dated  varchar(30), IN v_Notype varchar(20), IN v_Length int,
                                OUT cur_Code varchar(50))
  BEGIN
	DECLARE  ncount INTEGER;
  DECLARE  v_LatestNo INTEGER;
	DECLARE  v_str VARCHAR(512);

		SELECT COUNT(1) INTO ncount FROM number_generate WHERE dated = v_Dated AND numberType = v_Notype;
		IF ncount=0
		THEN
			INSERT INTO number_generate(dated,numberType,lasterNumber) VALUES(v_Dated,v_Notype,1); 
			SET v_LatestNo = 1;
		ELSE
			UPDATE number_generate SET lasterNumber = lasterNumber+1 WHERE dated=v_Dated AND numberType=v_Notype;
			SELECT  lasterNumber INTO v_LatestNo FROM number_generate WHERE dated = v_Dated AND numberType = v_Notype;
		END IF;
	SET v_str = LPAD(v_LatestNo,v_Length,'0');
	IF LENGTH(v_Dated) > 8
	THEN
		SELECT CONCAT(v_str) INTO cur_Code;
	ELSE 
		SELECT CONCAT(v_Notype,DATE_FORMAT(v_Dated,'%Y%m%d'),v_str) INTO cur_Code;
	END IF;
END;

