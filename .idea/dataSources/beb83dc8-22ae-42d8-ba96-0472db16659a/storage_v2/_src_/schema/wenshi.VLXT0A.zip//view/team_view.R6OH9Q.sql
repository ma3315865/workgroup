create view team_view as select `wenshi`.`t_svr_team`.`tid`         AS `tid`,
                                `wenshi`.`t_svr_team`.`tname`       AS `tname`,
                                `wenshi`.`t_svr_team`.`create_time` AS `create_time`,
                                `wenshi`.`t_svr_team`.`owner`       AS `owner`,
                                1                                   AS `type`
                         from `wenshi`.`t_svr_team`
                         union all select `wenshi`.`app_chat_room`.`yx_room_id`     AS `tid`,
                                          `wenshi`.`app_chat_room`.`name`           AS `name`,
                                          `wenshi`.`app_chat_room`.`create_date`    AS `create_time`,
                                          `wenshi`.`app_chat_room`.`owner_user_num` AS `owner`,
                                          2                                         AS `type`
                                   from `wenshi`.`app_chat_room`
                                   where ((`wenshi`.`app_chat_room`.`del_flag` = 0) and
                                          (`wenshi`.`app_chat_room`.`status` = 1));

